<section class="Section Section--style1 Section--promocoes u-paddingTop u-paddingBottom--inter">
	<div class="u-maxSize--container u-alignCenterBox u-alignCenter"><!-- Max Size Container -->
		<header class="Section-header Section-header-beforeTitleLine u-marginBottom--inter u-size16of24 u-alignCenterBox u-paddingVertical">
			<h2 class="Section-header-title Section-header-title--beforeTitleLine u-alignCenter u-paddingBottom--inter--half u-marginBottom--inter--half"><strong>COMPRAR INGRESSOS EM FORTALEZA-CE</strong></h2>
			<!-- <h3 class="Section-header-subtitle u-alignCenter">Subtitulo exemplo lorem ipsum dolor sit amet</h3> -->
		</header>
		<?php get_template_part('template-parts/promocoes/section-promocoes','loop'); ?>

</section>