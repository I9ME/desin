<ul class="SocialMediaBar u-positionRelative u-displayFlex u-flexDirectionRow u-sizeFull u-flexJustifyContentCenter">
			
	<!-- <li class="SocialMediaBar-site u-displayFlex u-flexAlignItemsCenter">
		<a class="u-displayBlock LinkHover" href="#" target="_blank">
			<i class="FigureIcon FigureIcon--a FigureIcon--site is-animating"></i>
			<i class="FigureIcon FigureIcon--b FigureIcon--site--hover is-animating"></i>
		</a>
	</li> -->
	<li class="SocialMediaBar-facebook u-displayFlex u-flexAlignItemsCenter">
		<a class="u-displayBlock LinkHover" href="https://www.facebook.com/desingressando/" target="_blank">
			<i class="FigureIcon FigureIcon--a FigureIcon--facebook is-animating"></i>
			<i class="FigureIcon FigureIcon--b FigureIcon--facebook--hover is-animating"></i>
		</a>
	</li>
	<li class="SocialMediaBar-instagram u-displayFlex u-flexAlignItemsCenter">
		<a class="u-displayBlock LinkHover" href="https://www.instagram.com/desingressando/" target="_blank">
			<i class="FigureIcon FigureIcon--a FigureIcon--instagram is-animating"></i>
			<i class="FigureIcon FigureIcon--b FigureIcon--instagram--hover is-animating"></i>
		</a>
	</li>
	<!-- <li class="SocialMediaBar-youtube u-displayFlex u-flexAlignItemsCenter">
		<a class="u-displayBlock LinkHover" href="https://www.youtube.com/" target="_blank">
			<i class="FigureIcon FigureIcon--a FigureIcon--youtube is-animating"></i>
			<i class="FigureIcon FigureIcon--b FigureIcon--youtube--hover is-animating"></i>
		</a>
	</li> -->

</ul>